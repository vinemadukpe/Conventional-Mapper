# Crypto-Ball-Mapper-Project
Here we modified static ball mapper by Dungnari BM graph model following strictly Dlotko algorithm. Region is used as a target feature while the stations are the points. the nodes are colored base on the region. we also made the graph static for easy usage on paper.
def Ballmapper(data, region_col, eps, metric='euclidean'):
    
    # Extracting numerical data and region information
    numerical_data = data.drop(columns=['Station', region_col])
    regions = data[region_col].values
    
    # Computing pairwise distances
    dist_matrix = squareform(pdist(numerical_data, metric))
    n_samples = dist_matrix.shape[0]
    
    # Initializing graph and landmark selection
    bm_graph = nx.Graph()
    landmarks = []
    points_covered = set()
    
    # Landmark selection and cluster formation
    while len(points_covered) < n_samples:
        for i in range(n_samples):
            if i not in points_covered:
                landmarks.append(i)
                points_covered.add(i)
                # Create a node for each landmark
                bm_graph.add_node(i, region=regions[i], points_covered=[i])
                break
           # Expanding clusters around landmarks
        for j in range(n_samples):
            if dist_matrix[landmarks[-1], j] <= eps:
                points_covered.add(j)
                bm_graph.nodes[landmarks[-1]]['points_covered'].append(j)
    
    # Connecting clusters with overlapping points
    for i in range(len(landmarks)):
        for j in range(i + 1, len(landmarks)):
            if set(bm_graph.nodes[landmarks[i]]['points_covered']) & set(bm_graph.nodes[landmarks[j]]['points_covered']):
                bm_graph.add_edge(landmarks[i], landmarks[j])
    
    return bm_graph, regions
    import numpy as np
from scipy.spatial.distance import pdist, squareform
import networkx as nx
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")

data = pd.read_csv('PM2.5_BM1.csv')

eps = 0.065

# Generating the Ball Mapper graph with specified parameters
bm_graph, regions = Ballmapper(data, 'Region', eps, metric='cosine')

# Define unique regions and assign a base color map
unique_regions = np.unique(regions)
color_map = plt.cm.get_cmap('hsv', len(unique_regions))

# Customization of colors for specific regions
region_to_color = {region: color_map(i) for i, region in enumerate(unique_regions)}
region_to_color['Central'] = '#03c04a'
region_to_color['Southern'] = '#fcd12a'
region_to_color['Northern'] = '#006837'
region_to_color['Eastern'] = '#a6d96a'
region_to_color['Sabah'] = '#a50026'
region_to_color['Sarawak'] = '#f46d43'
# Determine node sizes based on the number of points in each cluster
node_sizes = [len(bm_graph.nodes[i]['points_covered']) * 70 for i in bm_graph.nodes]  # Adjust size factor as needed

# Node colors based on the region-to-color mapping
node_colors = [region_to_color[bm_graph.nodes[i]['region']] for i in bm_graph.nodes]

# Visualization
plt.figure(figsize=(7, 4))
pos = nx.spring_layout(bm_graph, k=0.3, iterations=15, seed=30)
nx.draw_networkx_edges(bm_graph, pos, alpha=0.6)
nx.draw_networkx_nodes(bm_graph, pos, node_size=node_sizes, node_color=node_colors, alpha=0.8)
nx.draw_networkx_labels(bm_graph, pos, font_size=8, horizontalalignment='center')

# Legend to reflect colors
legend_handles = [plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=color, markersize=10, label=region) for region, color in region_to_color.items()]
plt.legend(handles=legend_handles, title="Regions", bbox_to_anchor=(1, 1))
#plt.title("PM2.5 Ball Mapper Graph with Cosine Metric, eps=0.065")
plt.axis('off')
plt.tight_layout()
plt.savefig('PM2.5_BM.png', dpi=300)
plt.show()
